let redux = require('redux');

const initialState = {money:1000.00};

//reducer function to manage data inside store
function appReducer(currentState = initialState,action) {
	const newState = {...currentState};
	console.log("Store managed by reducer!!");

	switch(action.type) {
		case 'DEPOSIT':
			newState.money = newState.money + action.amount; 			
			break;
		case 'WITHDRAW':
			newState.money = newState.money - action.amount; 			
			break;
	}
	
	return newState;
}


//Store creation using reducer
let store = redux.createStore(appReducer);
console.log("Store is ready with reducer!!")

//Application logic will subscribe to store in advance with a callback function
store.subscribe(()=>{
	console.log("Latest data in store : "+JSON.stringify(store.getState()));
});

store.subscribe(()=>{
	console.log("Displaying data in Column Chart : "+JSON.stringify(store.getState()));
});

store.subscribe(()=>{
	console.log("Displaying data in Pie Chart : "+JSON.stringify(store.getState()));
});

store.subscribe(()=>{
	console.log("Displaying data in Tabular form : "+JSON.stringify(store.getState()));
});


store.subscribe(()=>{
	console.log("Sendind data on mail : "+JSON.stringify(store.getState()));
});


//Action Creators
const depositAction = (amount) => {
	return {type:'DEPOSIT',amount:amount};
}

//Action Creators
const withdrawAction = (amount) => {
	return {type:'WITHDRAW',amount:amount};
}


//Application logic will send data to store
store.dispatch(depositAction(1000.00));
store.dispatch(depositAction(2000.00));
store.dispatch(depositAction(6000.00));
store.dispatch(depositAction(1000.00));
store.dispatch(depositAction(8000.00));
store.dispatch(withdrawAction(600.00));

