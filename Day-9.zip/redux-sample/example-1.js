let redux = require('redux');

const initialState = {money:1000.00};

//reducer function to manage data inside store
function appReducer(currentState = initialState,action) {
	const newState = {...currentState};
	console.log("Store managed by reducer!!");

	switch(action.type) {
		case 'DEPOSIT':
			newState.money = newState.money + 500.00; 			
			break;
		case 'WITHDRAW':
			newState.money = newState.money - 500.00; 			
			break;
	}
	
	return newState;
}



//Store creation using reducer
let store = redux.createStore(appReducer);
console.log("Store is ready with reducer!!")

//Application logic will send data to store
store.dispatch({type:'DEPOSIT'});
store.dispatch({type:'DEPOSIT'});
store.dispatch({type:'WITHDRAW'});
