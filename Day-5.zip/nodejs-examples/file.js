let fs = require('fs')

var data = fs.readFileSync('C:/dbs-html-javascript-react-march/Day-5/Notes-Days-5.txt')

console.log(data.toString())
