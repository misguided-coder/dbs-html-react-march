function sum(arg1,arg2) {
	console.log(`SUM : ${arg1+arg2}`)
}

exports.doSum = sum;
