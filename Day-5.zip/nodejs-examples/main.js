let math = require('./math.js')
let payroll = require('./payroll')

console.log("Main Module and Main entry point")

math.doSum(2,4)

console.log(payroll.title)

payroll.hra(20000.00)
payroll.da(20000.00)

var tax = new payroll.Tax()

console.log(tax.tds(50000.00))
console.log(tax.gst(500000.00))

