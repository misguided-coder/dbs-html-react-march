var crypto = require('crypto');

var cipher =  crypto.createCipher("aes128","tyagi");

var plainData = "500 million dollar balance in there in account"
cipher.update(plainData,"UTF8");
var encryptedData = cipher.final();

console.log(encryptedData.toString());
