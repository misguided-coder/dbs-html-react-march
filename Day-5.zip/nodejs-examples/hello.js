var i = 1000
console.log(i)

let j = 1000
console.log(j)

const k = 1000
console.log(k)


function doWork() {
	console.log("Working.....")
}

doWork()

for(var i=0;i<10;i++){
	console.log(i)
}


class Employee {
}

class Manager extend Employee {
}

console.log(new Employee())
