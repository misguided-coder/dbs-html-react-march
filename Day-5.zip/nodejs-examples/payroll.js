function hra(basic) {
	console.log(`HRA : ${basic * .40}`)
}

function da(basic) {
	console.log(`DA : ${basic * .10}`)
}

const title = "Simple HRA Module"

class Tax {

    tds(basic) {
	return basic * .30;
    }	

    gst(amount) {
	return amount * .18;
    }	
}


exports.title = title;
exports.hra = hra;
exports.da = da;
exports.Tax = Tax;


